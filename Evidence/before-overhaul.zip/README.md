# Aether Grounds

A Windows racing game by Aljay Leodones, built in Unity 6 with editable Blender assets.

Run **Build/Aether Grounds.exe**. The Unity project is this folder; its scene is `Assets/Scenes/AetherGrounds.unity`. Blender source is `ArtSource/AetherGrounds.blend`.

## Play

- W / Up: accelerate. S / Down: brake, then reverse.
- A / D or Left / Right: steer.
- Space: drift. Drifting replenishes boost.
- Left Shift: use rechargeable boost.
- E: use the collected power-up.
- R: return an overturned or stuck car to the road.
- Escape: pause and resume.

Game Setup selects one of three circuits, 0–11 AI opponents, 1–5 laps, difficulty, and power-ups. Finish races for credits. The Garage saves paint, wheel finish, window tint, and engine/tire/brake upgrades locally. Five base cars are available immediately.

## Source

- `Assets/Scripts/Vehicle.cs`: four-point spring/damper suspension, tire forces, braking, drift, AI steering, boost and collisions.
- `Assets/Scripts/TrackWorld.cs`: three large closed circuits, terrain, road meshes, barriers and Blender environment assets.
- `Assets/Scripts/Game.cs`: menus, garage, checkpoints, positions, results, power-ups and smoke-test mode.
- `Assets/Shaders`: stepped lighting, outlines and gradient sky.
- `Tools/build_assets.py`: runs inside Blender and creates the five editable vehicles and environment library. Mesh parts retain semantic names and material roles. Exports in `Assets/Resources/Models` are generated from the Blender mesh geometry.
- `Assets/Editor/BuildGame.cs`: creates the scene and builds the Windows game.
- `Assets/Art/Prefabs`: editable Unity prefabs for all five cars and six environment pieces, with mesh and material assets alongside them. Use the **Aether Grounds** editor menu to reopen the game scene or regenerate these prefabs.
- `Evidence`: build logs and real rendered screenshots.

## Rebuild

Use the installed Blender to run `Tools/build_assets.py` in background mode. Then run Unity with this project and `-executeMethod BuildGame.Build -batchmode -quit`. Opening the scene in Unity and pressing Play also runs the game.

This is a playable first version. The starting car is a stylized interpretation of the supplied front three-quarter reference; it is not an exact replica. Driving uses a rigidbody and simulated suspension with arcade assistance. It does not implement a full tire simulation, body deformation, multiplayer, controller mapping or licensed audio. Track scenery and geometry are generated deterministically when a race starts. Cosmetic wheel finishes and window tints do not affect stats; handling upgrades do.
