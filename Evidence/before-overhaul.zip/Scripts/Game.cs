using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Aether {
 public class Game:MonoBehaviour {
  public enum State {Menu,Countdown,Race,Pause,Results}
  public State state=State.Menu;public TrackWorld track;public List<Vehicle> racers=new List<Vehicle>();public Vehicle player;public Camera cam;public int laps=3,aiCount=7,mapIndex,selectedCar,paintIndex,wheelIndex,windowIndex,engineLevel,tireLevel,brakeLevel,difficulty=1;public bool powerups=true;public float raceTime,cameraShake,volume=.55f;public float difficultyFactor=>new[]{.72f,.88f,1.04f}[difficulty];
  public static readonly Color[] Paints={new Color(.075f,.095f,.13f),new Color(.12f,.70f,.70f),new Color(.75f,.17f,.46f),new Color(.94f,.56f,.18f),new Color(.81f,.85f,.89f),new Color(.34f,.25f,.68f)};
  public static readonly string[] PaintNames={"Graphite","Lagoon","Berry","Sunburst","Pearl","Iris"};
  public string menu="Play";GameObject showroom,preview;float countdown=3.8f,orbit=-35;Vector3 cameraVel;string message="";float messageTimer;GUIStyle text,title,button,small;Texture2D pixel;public int credits=1200;bool loading;int finishedCount;float resultDelay;List<Pickup> boxes=new List<Pickup>();bool testing;float testTimer;int testStage;string evidencePath;State beforePause;int testMap;float testFps;int testFrames;
  string[] botNames={"Sir Skids-a-Lot","Brake Expectations","Wheelie Nelson","Clutch Potato","Tofu Fast","Bumper Dumpling","Oops All Boost","Driftwood Mac","Lord of the Rims","Pasta La Vista","No Turn Intended"};
  void Awake(){Application.targetFrameRate=120;QualitySettings.vSyncCount=0;Physics.defaultSolverIterations=10;Physics.defaultSolverVelocityIterations=4;Time.fixedDeltaTime=1/100f;Screen.SetResolution(1600,900,FullScreenMode.Windowed);Load();cam=Camera.main;if(!cam){cam=new GameObject("Main Camera").AddComponent<Camera>();cam.tag="MainCamera";cam.gameObject.AddComponent<AudioListener>();}cam.nearClipPlane=.08f;cam.farClipPlane=3000;cam.fieldOfView=53;cam.allowHDR=true;cam.backgroundColor=new Color(.16f,.2f,.3f);RenderSettings.ambientLight=new Color(.66f,.72f,.87f);var sun=new GameObject("Sun").AddComponent<Light>();sun.type=LightType.Directional;sun.transform.rotation=Quaternion.Euler(42,-35,0);sun.intensity=1.15f;sun.shadows=LightShadows.Soft;QualitySettings.shadowDistance=150;QualitySettings.shadows=ShadowQuality.All;QualitySettings.antiAliasing=4;MakeShowroom();string[] args=Environment.GetCommandLineArgs();testing=args.Contains("-aetherTest");evidencePath=Application.dataPath+"/../../Evidence";}
  void Load(){selectedCar=PlayerPrefs.GetInt("car",0);paintIndex=PlayerPrefs.GetInt("paint",0);wheelIndex=PlayerPrefs.GetInt("wheels",0);windowIndex=PlayerPrefs.GetInt("glass",0);engineLevel=PlayerPrefs.GetInt("engine",0);tireLevel=PlayerPrefs.GetInt("tires",0);brakeLevel=PlayerPrefs.GetInt("brakes",0);credits=PlayerPrefs.GetInt("credits",1200);volume=PlayerPrefs.GetFloat("volume",.55f);}
  void Start(){var editorPreview=GameObject.Find("Editor Preview");if(editorPreview)Destroy(editorPreview);}
  void Save(){if(testing)return;PlayerPrefs.SetInt("car",selectedCar);PlayerPrefs.SetInt("paint",paintIndex);PlayerPrefs.SetInt("wheels",wheelIndex);PlayerPrefs.SetInt("glass",windowIndex);PlayerPrefs.SetInt("engine",engineLevel);PlayerPrefs.SetInt("tires",tireLevel);PlayerPrefs.SetInt("brakes",brakeLevel);PlayerPrefs.SetInt("credits",credits);PlayerPrefs.SetFloat("volume",volume);PlayerPrefs.Save();}
  void MakeShowroom(){
   showroom=new GameObject("Garage display");RenderSettings.fog=false;var sky=new Material(Shader.Find("Aether/Sky"));sky.SetColor("_Top",new Color(.12f,.16f,.34f));sky.SetColor("_Horizon",new Color(.53f,.45f,.64f));RenderSettings.skybox=sky;
   var floor=TrackWorld.Cube("Garage floor",new Vector3(0,-.23f,0),new Vector3(150,.4f,150),ModelLibrary.Material("garagefloor",new Color(.15f,.20f,.29f),0,0),true);floor.transform.SetParent(showroom.transform);
   var plinth=GameObject.CreatePrimitive(PrimitiveType.Cylinder);plinth.name="Car display";plinth.transform.SetParent(showroom.transform);plinth.transform.position=new Vector3(0,-.1f,0);plinth.transform.localScale=new Vector3(7.3f,.14f,7.3f);plinth.GetComponent<Renderer>().sharedMaterial=ModelLibrary.Material("plinth",new Color(.21f,.28f,.37f));
   for(int i=0;i<60;i++){float a=i*Mathf.PI*2/60;var o=TrackWorld.Cube("Display lights",new Vector3(Mathf.Cos(a)*3.55f,.046f,Mathf.Sin(a)*3.55f),new Vector3(.17f,.025f,.055f),ModelLibrary.Material("displaycyan",new Color(.19f,.87f,.87f),.4f),false);o.transform.rotation=Quaternion.Euler(0,-a*Mathf.Rad2Deg,0);o.transform.SetParent(showroom.transform);}
   for(int i=0;i<18;i++){float a=i*Mathf.PI*2/18;var o=ModelLibrary.Create(i%3==0?"CrystalCluster":"AlienTree",showroom.transform);o.transform.position=new Vector3(Mathf.Cos(a)*22,-.02f,Mathf.Sin(a)*22);o.transform.localScale=Vector3.one*(1+i%3*.3f);}
   ShowCar();
  }
  void ShowCar(){if(preview)Destroy(preview);preview=ModelLibrary.Create(CarSpec.All[selectedCar].name,showroom.transform);ModelLibrary.Customize(preview,Paints[paintIndex],paintIndex==0?new Color(.95f,.055f,.11f):new Color(.26f,.93f,.87f),wheelIndex,windowIndex);}
  IEnumerator Begin(){
   if(loading)yield break;loading=true;Save();yield return null;Destroy(showroom);if(track)Destroy(track.gameObject);foreach(var v in racers)if(v)Destroy(v.gameObject);foreach(var p in boxes)if(p)Destroy(p.gameObject);foreach(var r in FindObjectsByType<Rocket>(FindObjectsSortMode.None))Destroy(r.gameObject);racers.Clear();boxes.Clear();finishedCount=0;resultDelay=0;
   track=new GameObject(TrackWorld.Names[mapIndex]).AddComponent<TrackWorld>();track.Generate(mapIndex);
   for(int i=0;i<=aiCount;i++){int n=(TrackWorld.Count-2-i/2*2)%TrackWorld.Count;Vector3 p=track.points[n]+track.Right(n)*(i%2==0?-3:3)+Vector3.up*.55f;var v=new GameObject(i==0?"Player":botNames[(i-1)%botNames.Length]).AddComponent<Vehicle>();v.Initialize(this,i==0?selectedCar:(i-1)%5,i==0,i==0?"You":botNames[(i-1)%botNames.Length],p,Quaternion.LookRotation(track.Forward(n)),i==0?engineLevel:0,i==0?tireLevel:0,i==0?brakeLevel:0);racers.Add(v);if(i==0){player=v;ModelLibrary.Customize(v.model,Paints[paintIndex],paintIndex==0?new Color(.95f,.055f,.11f):new Color(.26f,.93f,.87f),wheelIndex,windowIndex);}else ModelLibrary.Customize(v.model,Paints[(i+1)%6],Paints[(i+3)%6],i%3,i%3);}
   if(powerups)foreach(Vector3 p in track.pickups){var o=GameObject.CreatePrimitive(PrimitiveType.Cube);o.name="Power-up";Destroy(o.GetComponent<Collider>());o.transform.position=p;o.transform.localScale=Vector3.one*1.3f;o.GetComponent<Renderer>().sharedMaterial=ModelLibrary.Material("pickup",new Color(.25f,.93f,.84f),.3f);var box=o.AddComponent<Pickup>();box.game=this;box.home=p;boxes.Add(box);}
   raceTime=0;countdown=3.8f;state=State.Countdown;cam.transform.position=player.transform.position-player.transform.forward*9+Vector3.up*4;cam.transform.LookAt(player.transform.position+Vector3.up);cameraVel=Vector3.zero;loading=false;
  }
  public void StartRace(){Time.timeScale=1;StartCoroutine(Begin());}
  void Update(){
   if(messageTimer>0)messageTimer-=Time.unscaledDeltaTime;
   if(state==State.Countdown){countdown-=Time.deltaTime;if(countdown<=0){state=State.Race;Toast("Go!");}}
   if(state==State.Race){raceTime+=Time.deltaTime;var ordered=racers.OrderByDescending(v=>v.finished?100000-v.finishTime:v.progress).ToList();for(int i=0;i<ordered.Count;i++)ordered[i].place=i+1;if(player.finished){resultDelay+=Time.deltaTime;if(resultDelay>2.5f){state=State.Results;Time.timeScale=0;}}}
   if(Input.GetKeyDown(KeyCode.Escape)){if(state==State.Race||state==State.Countdown){beforePause=state;state=State.Pause;Time.timeScale=0;}else if(state==State.Pause){state=beforePause;Time.timeScale=1;}}
   if(state==State.Menu)orbit+=Time.deltaTime*5;
   cameraShake=Mathf.Max(0,cameraShake-Time.unscaledDeltaTime);
   if(testing)TestDriver();
  }
  void LateUpdate(){
   if(state==State.Menu&&preview){Vector3 offset=Quaternion.Euler(0,orbit,0)*new Vector3(3.3f,2.5f,7.4f);cam.transform.position=offset;cam.transform.LookAt(new Vector3(0,.55f,0));cam.transform.rotation*=Quaternion.Euler(0,menu=="Play"?-14:0,0);cam.fieldOfView=45;}
   else if(player){Vector3 forward=player.transform.forward;if(player.body.linearVelocity.magnitude>4)forward=Vector3.Slerp(forward,player.body.linearVelocity.normalized,.22f);forward.y=0;forward.Normalize();Vector3 desired=player.transform.position-forward*8.6f+Vector3.up*3.9f;cam.transform.position=Vector3.SmoothDamp(cam.transform.position,desired,ref cameraVel,.14f,200,Time.unscaledDeltaTime);Vector3 focus=player.transform.position+player.transform.forward*5+Vector3.up*1.05f;cam.transform.rotation=Quaternion.Slerp(cam.transform.rotation,Quaternion.LookRotation(focus-cam.transform.position),Time.unscaledDeltaTime*10);cam.fieldOfView=Mathf.Lerp(cam.fieldOfView,60+Mathf.Clamp01(player.speed/250)*13+(player.boost>0?7:0),Time.unscaledDeltaTime*3);if(cameraShake>0)cam.transform.position+=UnityEngine.Random.insideUnitSphere*cameraShake*.25f;}
   if(player)foreach(var v in racers)if(v!=player)foreach(var r in v.model.GetComponentsInChildren<Renderer>())r.shadowCastingMode=Vector3.Distance(v.transform.position,cam.transform.position)<5?UnityEngine.Rendering.ShadowCastingMode.ShadowsOnly:UnityEngine.Rendering.ShadowCastingMode.On;
  }
  public void Toast(string s){message=s;messageTimer=3;}
  public void OnFinish(Vehicle v){finishedCount++;if(v.player){int award=500+Mathf.Max(0,aiCount+2-finishedCount)*80;credits+=award;Save();Toast("Finished! +"+award+" credits");}}
  static Material fxMaterial;static AudioClip impactClip;
  public static Material FXMaterial(){if(fxMaterial)return fxMaterial;var tex=new Texture2D(32,32,TextureFormat.RGBA32,false);var colors=new Color[1024];for(int y=0;y<32;y++)for(int x=0;x<32;x++){float a=Mathf.Clamp01(1-new Vector2(x-15.5f,y-15.5f).magnitude/15.5f);colors[y*32+x]=new Color(1,1,1,a*a);}tex.SetPixels(colors);tex.Apply();fxMaterial=new Material(Shader.Find("Sprites/Default"));fxMaterial.mainTexture=tex;return fxMaterial;}
  public void Burst(Vector3 p,Color c,float amount){var o=new GameObject("Impact sparks");o.transform.position=p;var ps=o.AddComponent<ParticleSystem>();var main=ps.main;main.loop=false;main.startLifetime=.35f;main.startSpeed=7*amount;main.startSize=.16f;main.startColor=c;main.gravityModifier=1;var emission=ps.emission;emission.rateOverTime=0;emission.SetBursts(new[]{new ParticleSystem.Burst(0,(short)(24*amount))});var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Sphere;shape.radius=.2f;ps.GetComponent<ParticleSystemRenderer>().material=FXMaterial();ps.Play();if(player&&Vector3.Distance(p,player.transform.position)<35){if(!impactClip){impactClip=AudioClip.Create("Collision impact",11025,1,44100,false);var samples=new float[11025];var random=new System.Random(42);for(int i=0;i<samples.Length;i++)samples[i]=((float)random.NextDouble()*2-1)*Mathf.Exp(-i/1500f)*.8f;impactClip.SetData(samples,0);}var sound=o.AddComponent<AudioSource>();sound.clip=impactClip;sound.volume=volume*Mathf.Min(.35f,amount*.15f);sound.pitch=.7f+amount*.2f;sound.Play();}Destroy(o,1.5f);}
  void ReturnMenu(){Time.timeScale=1;foreach(var p in boxes)if(p)Destroy(p.gameObject);foreach(var r in FindObjectsByType<Rocket>(FindObjectsSortMode.None))Destroy(r.gameObject);foreach(var v in racers)if(v)Destroy(v.gameObject);racers.Clear();if(track)Destroy(track.gameObject);player=null;state=State.Menu;MakeShowroom();}
  void Styles(){if(pixel)return;pixel=Texture2D.whiteTexture;text=new GUIStyle(GUI.skin.label){fontSize=21,normal={textColor=new Color(.89f,.94f,1)},wordWrap=true};small=new GUIStyle(text){fontSize=17};title=new GUIStyle(text){fontSize=50,fontStyle=FontStyle.Bold};button=new GUIStyle(GUI.skin.button){fontSize=21,alignment=TextAnchor.MiddleCenter,normal={background=Texture2D.whiteTexture,textColor=Color.white},hover={background=Texture2D.whiteTexture,textColor=Color.white},active={background=Texture2D.whiteTexture,textColor=Color.white},border=new RectOffset(0,0,0,0)};}
  Color ink=new Color(.045f,.07f,.12f,.96f),cyan=new Color(.27f,.90f,.86f),muted=new Color(.6f,.69f,.79f);
  void Panel(float x,float y,float w,float h,float a=.94f){GUI.color=new Color(.045f,.07f,.12f,a);GUI.DrawTexture(new Rect(x,y,w,h),pixel);GUI.color=Color.white;}
  void Line(float x,float y,float w,Color c){GUI.color=c;GUI.DrawTexture(new Rect(x,y,w,2),pixel);GUI.color=Color.white;}
  void Label(string s,float x,float y,float w=400,float h=34,int size=21,Color? color=null,bool bold=false){var st=new GUIStyle(text){fontSize=size,fontStyle=bold?FontStyle.Bold:FontStyle.Normal};st.normal.textColor=color??Color.white;GUI.Label(new Rect(x,y,w,h),s,st);}
  bool Button(string s,float x,float y,float w,float h=48,bool primary=false){GUI.backgroundColor=primary?new Color(.14f,.62f,.60f):new Color(.14f,.20f,.29f);bool b=GUI.Button(new Rect(x,y,w,h),s,button);GUI.backgroundColor=Color.white;return b;}
  void Bar(string label,float value,float max,float x,float y,float width=340,string suffix=""){Label(label,x,y,width,30,18,muted);Label(value.ToString("0")+suffix,x+width-100,y,100,30,18,Color.white);Panel(x,y+31,width,5,1);GUI.color=cyan;GUI.DrawTexture(new Rect(x,y+31,width*Mathf.Clamp01(value/max),5),pixel);GUI.color=Color.white;}
  void OnGUI(){Styles();GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,new Vector3(Screen.width/1600f,Screen.height/900f,1));
   if(loading){Panel(0,0,1600,900);Label("Building the race…",530,400,600,70,40);return;}
   if(state==State.Menu)MenuGUI();else RaceGUI();
   if(messageTimer>0){Panel(550,797,500,49,.94f);Label(message,568,806,468,36,20,cyan);}
  }
  void MenuGUI(){
   Panel(0,0,1600,107,.92f);Label("AETHER GROUNDS",40,20,760,62,46,null,true);Label("By Aljay Leodones",44,75,500,25,17,muted);Label(credits+" credits",1370,42,205,35,22,cyan,true);
   string[] tabs={"Play","Game Setup","Garage","Controls"};for(int i=0;i<4;i++)if(Button(tabs[i],40+i*178,128,164,44,menu==tabs[i]))menu=tabs[i];
   if(menu=="Play"){
    Panel(40,196,430,424);Label("Your next race",65,220,380,49,32,null,true);Line(65,274,377,cyan);Label(TrackWorld.Names[mapIndex],65,298,380,45,27,cyan,true);Label(TrackWorld.Descriptions[mapIndex],65,346,350,80,20,muted);Label(aiCount+" AI opponents  ·  "+laps+" laps",65,447,360);Label(powerups?"Power-ups on":"Power-ups off",65,483,360,30,20,muted);if(Button("Play",65,545,350,52,true))StartRace();
    Panel(1080,635,480,75,.86f);Label("Starting car: "+CarSpec.All[selectedCar].name,1100,649,450,28,22,null,true);Label("Customize its look and handling in Garage",1100,683,450,28,17,muted);
   }else if(menu=="Game Setup")SetupGUI();else if(menu=="Garage")GarageGUI();else ControlsGUI();
   Panel(0,735,1600,165,.96f);Label("Base cars",40,752,260,30,19,muted);for(int i=0;i<5;i++){
    float x=40+i*308;if(Button(CarSpec.All[i].name,x,794,288,54,selectedCar==i)){selectedCar=i;ShowCar();Save();}Label(new[]{"Balanced supercar","Muscle coupe","Agile hatchback","Rally buggy","High-speed racer"}[i],x,858,290,30,17,muted);
   }
  }
  void SetupGUI(){
   Panel(40,196,590,508);Label("Game Setup",65,216,490,50,32,null,true);Label("Choose a circuit",65,276,450,30,20,muted);
   for(int i=0;i<3;i++){if(Button(TrackWorld.Names[i],65,318+i*62,535,50,mapIndex==i))mapIndex=i;}
   Label(TrackWorld.Descriptions[mapIndex],65,516,520,78,20,muted);if(Button("Play",65,632,535,49,true))StartRace();
   Panel(1040,196,520,508);Label("Race settings",1065,218,450,45,31,null,true);
   Stepper("AI opponents",ref aiCount,0,11,1065,283);Stepper("Laps",ref laps,1,5,1065,348);Stepper("Difficulty",ref difficulty,0,2,1065,413,new[]{"Easy","Normal","Hard"});
   if(Button(powerups?"Power-ups: On":"Power-ups: Off",1065,493,465,48,powerups))powerups=!powerups;
   Label("AI drivers use the same suspension and road physics as your car.",1065,570,455,94,19,muted);
  }
  void Stepper(string name,ref int value,int min,int max,float x,float y,string[] names=null){Label(name,x,y+6,230);if(Button("−",x+235,y,48,40))value=Mathf.Max(min,value-1);Label(names==null?value.ToString():names[value],x+294,y+7,110,30,19,cyan);if(Button("+",x+417,y,48,40))value=Mathf.Min(max,value+1);}
  void GarageGUI(){
   Panel(40,196,420,510);Label(CarSpec.All[selectedCar].name,65,214,365,54,36,null,true);Label(CarSpec.All[selectedCar].description,65,270,357,60,18,muted);
   CarSpec s=CarSpec.All[selectedCar];Bar("Top speed",(s.speed+engineLevel*3)*3.6f,330,65,350,365," km/h");Bar("Acceleration",s.accel+engineLevel*1.5f,22,65,413,365);Bar("Braking",s.brake+brakeLevel*2,33,65,476,365);Bar("Grip",s.grip+tireLevel*.8f,14,65,539,365);Label("Hold Space to drift. Drift to refill boost.",65,635,345,45,18,muted);
   Panel(1040,196,520,510);Label("Customize",1065,214,460,45,31,null,true);
   Label("Paint · "+PaintNames[paintIndex],1065,272,430,30,19,muted);for(int i=0;i<6;i++){GUI.backgroundColor=Paints[i]*1.5f;if(GUI.Button(new Rect(1065+i*76,311,61,37),paintIndex==i?"✓":"",button)){paintIndex=i;ShowCar();Save();}GUI.backgroundColor=Color.white;}
   int old=wheelIndex;Stepper("Wheels",ref wheelIndex,0,2,1065,368,new[]{"Alloy","Gold","White"});if(old!=wheelIndex){ShowCar();Save();}old=windowIndex;Stepper("Windows",ref windowIndex,0,2,1065,418,new[]{"Smoke","Cyan","Violet"});if(old!=windowIndex){ShowCar();Save();}
   Label("Handling upgrades · 300 credits each",1065,479,460,29,18,muted);
   Upgrade("Engine",ref engineLevel,1065,519);Upgrade("Tires",ref tireLevel,1227,519);Upgrade("Brakes",ref brakeLevel,1389,519);
   Label("Paint, wheels and window tint are free. Handling upgrades carry across your cars.",1065,601,455,80,18,muted);
  }
  void Upgrade(string name,ref int level,float x,float y){Label(name+" "+level+"/3",x,y,155,30,19);if(Button(level>=3?"Max":"+ Upgrade",x,y+35,144,42)&&level<3){if(credits>=300){credits-=300;level++;Save();}else Toast("Earn more credits by finishing races");}}
  void ControlsGUI(){Panel(40,196,600,508);Label("Controls",65,219,530,49,32,null,true);string[] lines={"W / ↑     Accelerate","S / ↓     Brake · hold to reverse","A D / ← →     Steer","Space     Drift","Left Shift     Boost","E     Use power-up","R     Reset car to road","Esc     Pause / Resume"};for(int i=0;i<lines.Length;i++)Label(lines[i],65,287+i*43,535,35,21,i<4?Color.white:muted);Panel(1040,196,520,508);Label("Power-ups",1065,220,450,45,31,null,true);Label("Boost — extra acceleration for 3 seconds\n\nShield — absorbs one hit for 8 seconds\n\nRocket — follows an opponent ahead\n\nPulse — pushes nearby opponents",1065,287,448,300,20);Label("Audio volume",1065,613,450,30,20,muted);float old=volume;volume=GUI.HorizontalSlider(new Rect(1065,659,450,25),volume,0,1);if(Mathf.Abs(old-volume)>.01f)Save();}
  void RaceGUI(){
   if(!player)return;Panel(28,25,288,119,.92f);Label(player.place+" / "+racers.Count,48,35,240,59,44,null,true);Label("Lap "+Mathf.Clamp((int)(Mathf.Max(0,player.progress)/TrackWorld.Count)+1,1,laps)+" / "+laps,49,99,240,32,21,cyan);
   Panel(636,25,328,71,.9f);Label(TrackWorld.Names[mapIndex],656,35,290,30,22,null,true);Label(TimeFormat(raceTime),656,67,280,26,17,muted);
   MiniMap();Panel(1272,698,300,170,.92f);Label(player.speed.ToString("000"),1294,709,236,81,65,null,true);Label("km/h",1490,757,70,31,18,muted);Bar("Boost",player.energy,100,1294,811,252);
   Panel(28,733,365,135,.93f);Label(player.item==""?"Collect a power-up":player.item+"  [E]",49,751,325,40,25,player.item==""?muted:cyan,true);Label(player.shield>0?"Shield: "+player.shield.ToString("0.0")+"s":"Shift: Boost   ·   Space: Drift",49,810,322,31,18,muted);
   var leaders=racers.OrderBy(v=>v.place).Take(5).ToArray();Panel(28,166,288,184,.84f);for(int i=0;i<leaders.Length;i++)Label(leaders[i].place+"  "+leaders[i].driver,44,179+i*32,259,29,17,leaders[i].player?cyan:Color.white);
   if(state==State.Countdown){Panel(662,327,276,161,.82f);Label(countdown>1?Mathf.CeilToInt(countdown-1).ToString():"Ready",706,357,230,91,65,cyan,true);}
   if(state==State.Pause){Panel(0,0,1600,900,.65f);Panel(580,223,440,459);Label("Paused",620,256,360,61,42,null,true);if(Button("Resume",620,353,360,54,true)){state=beforePause;Time.timeScale=1;}if(Button("Restart",620,429,360,54)){StartRace();}if(Button("Game Setup",620,505,360,54)){ReturnMenu();menu="Game Setup";}if(Button("Quit",620,581,360,54)){Save();Application.Quit();}}
   if(state==State.Results){Panel(0,0,1600,900,.75f);Panel(414,115,772,650);Label("Match Results",450,146,700,62,43,null,true);Label(TrackWorld.Names[mapIndex]+" · "+laps+(laps==1?" lap":" laps"),451,212,685,37,22,cyan);var order=racers.OrderBy(v=>v.place).Take(12).ToArray();for(int i=0;i<order.Length;i++){var v=order[i];Label(v.place+"   "+v.driver,453,272+i*30,450,29,20,v.player?cyan:Color.white);Label(v.finished?TimeFormat(v.finishTime):"Not finished",974,272+i*30,180,29,19,muted);}if(Button("Restart",451,662,319,57,true))StartRace();if(Button("Game Setup",801,662,345,57)){ReturnMenu();menu="Game Setup";}}
  }
  string TimeFormat(float t)=>((int)t/60).ToString("00")+":"+(t%60).ToString("00.00");
  void MiniMap(){Rect r=new Rect(1328,25,244,244);Panel(r.x,r.y,r.width,r.height,.87f);Label("Circuit",1345,36,200,27,17,muted);Vector2 P(Vector3 p)=>new Vector2(r.x+122+p.x*.25f,r.y+137-p.z*.25f);for(int i=0;i<TrackWorld.Count;i+=2){Vector2 p=P(track.points[i]);GUI.color=new Color(.39f,.52f,.64f);GUI.DrawTexture(new Rect(p.x-2,p.y-2,4,4),pixel);}foreach(var v in racers){Vector2 p=P(v.transform.position);GUI.color=v.player?cyan:new Color(1,.50f,.35f);GUI.DrawTexture(new Rect(p.x-4,p.y-4,8,8),pixel);}GUI.color=Color.white;}
  // Optional reproducible smoke test; logs assertions and captures actual rendered frames.
  void TestDriver(){
   testTimer+=Time.unscaledDeltaTime;
   if(testStage==0&&testTimer>4){ScreenCapture.CaptureScreenshot(evidencePath+"/menu.png");testStage++;testTimer=0;}
   else if(testStage==1&&testTimer>1){menu="Garage";ScreenCapture.CaptureScreenshot(evidencePath+"/garage.png");testStage=10;testTimer=0;}
   else if(testStage==10&&testTimer>1){laps=1;StartRace();testStage=2;testTimer=0;}
   else if(testStage==2&&state==State.Race){player.player=false;testStage++;testTimer=0;Debug.Log("AETHER_TEST Race started. cars="+racers.Count+" trackMeters="+track.length);}
   else if(testStage==3&&testTimer>18){ScreenCapture.CaptureScreenshot(evidencePath+"/race-"+mapIndex+".png");Debug.Log("AETHER_TEST after18s speed="+player.speed+" progress="+player.progress+" grounded="+player.grounded+" position="+player.transform.position);player.item="Shield";player.UseItem();Debug.Assert(player.shield>0,"Shield failed");player.item="Boost";player.UseItem();Debug.Assert(player.boost>0,"Boost failed");testStage++;testTimer=0;}
   else if(testStage==4){testFps+=Time.unscaledDeltaTime;testFrames++;if(state==State.Results||testTimer>100){Debug.Log("AETHER_TEST map="+mapIndex+" state="+state+" fps="+(testFrames/testFps)+" "+string.Join("; ",racers.Select(v=>v.driver+" progress="+v.progress.ToString("F1")+" speed="+v.speed.ToString("F1"))));Debug.Assert(state==State.Results,"Race did not finish");ScreenCapture.CaptureScreenshot(evidencePath+"/results-"+mapIndex+".png");testStage++;testTimer=0;}}
   else if(testStage==5&&testTimer>1){if(mapIndex<2){mapIndex++;StartRace();testStage=2;testTimer=0;testFps=0;testFrames=0;}else Application.Quit();}
  }
 }
 public class Pickup:MonoBehaviour {public Game game;public Vector3 home;float cooldown;Renderer visual;void Start(){visual=GetComponent<Renderer>();}void Update(){if(game.state!=Game.State.Race&&game.state!=Game.State.Countdown)return;transform.rotation=Quaternion.Euler(20,Time.time*65,20);transform.position=home+Vector3.up*Mathf.Sin(Time.time*2+home.x)*.25f;if(cooldown>0){cooldown-=Time.deltaTime;visual.enabled=false;return;}visual.enabled=true;foreach(var v in game.racers)if(v.item==""&&Vector3.Distance(v.transform.position+Vector3.up,home)<2.7f){v.item=new[]{"Boost","Shield","Rocket","Pulse"}[UnityEngine.Random.Range(0,4)];cooldown=7;game.Burst(home,new Color(.2f,1,.85f),.6f);if(v.player)game.Toast(v.item+" collected · press E");break;}}}
}
