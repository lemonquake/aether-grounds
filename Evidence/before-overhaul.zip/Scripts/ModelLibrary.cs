using System;
using System.Collections.Generic;
using UnityEngine;
namespace Aether {
 [Serializable] public class ModelPart { public string name,material; public float[] color,vertices; public int[] triangles; }
 [Serializable] public class ModelData {public string name;public ModelPart[] parts;}
 public static class ModelLibrary {
  static Dictionary<string,ModelData> data=new Dictionary<string,ModelData>();
  static Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>();
  static Dictionary<string,Material> mats=new Dictionary<string,Material>();
  public static Material Material(string key,Color color,float glow=0,float outline=.012f){
   if(mats.TryGetValue(key,out var m))return m;
   m=new Material(Shader.Find("Aether/Toon")){name=key,color=color};m.SetFloat("_Emission",glow);m.SetFloat("_Outline",outline);m.enableInstancing=true;mats[key]=m;return m;
  }
  public static GameObject Create(string name,Transform parent=null){
   if(!data.TryGetValue(name,out var d)){d=JsonUtility.FromJson<ModelData>(Resources.Load<TextAsset>("Models/"+name).text);data[name]=d;}
   var root=new GameObject(name);if(parent)root.transform.SetParent(parent,false);
   var groups=new Dictionary<string,List<CombineInstance>>();var colors=new Dictionary<string,Color>();
   foreach(var p in d.parts){
    string group=(p.name.StartsWith("WheelF")||p.name.StartsWith("WheelR")?p.name.Substring(0,7)+"/":"Body/")+p.material;
    if(!groups.ContainsKey(group)){groups[group]=new List<CombineInstance>();colors[group]=new Color(p.color[0],p.color[1],p.color[2]);}
    string mk=name+"/"+p.name+"/"+Array.IndexOf(d.parts,p);
    if(!meshes.TryGetValue(mk,out Mesh m)){
     m=new Mesh(){name=mk};var v=new Vector3[p.vertices.Length/3];for(int i=0;i<v.Length;i++)v[i]=new Vector3(p.vertices[i*3],p.vertices[i*3+1],p.vertices[i*3+2]);m.vertices=v;m.triangles=p.triangles;m.RecalculateNormals();m.RecalculateBounds();meshes[mk]=m;
    }
    groups[group].Add(new CombineInstance(){mesh=m,transform=Matrix4x4.identity});
   }
   var wheelRoots=new Dictionary<string,Transform>();
   foreach(var kv in groups){
    string cache=name+"/combined/"+kv.Key;
    if(!meshes.TryGetValue(cache,out Mesh combined)){combined=new Mesh(){name=cache,indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};combined.CombineMeshes(kv.Value.ToArray(),true,true);meshes[cache]=combined;}
    string materialName=kv.Key.Split('/')[1];Transform par=root.transform;
    if(kv.Key.StartsWith("Wheel")){
     string wn=kv.Key.Split('/')[0];if(!wheelRoots.TryGetValue(wn,out par)){par=new GameObject(wn).transform;par.SetParent(root.transform,false);wheelRoots[wn]=par;}
    }
    var o=new GameObject(materialName);o.transform.SetParent(par,false);o.AddComponent<MeshFilter>().sharedMesh=combined;
    var mr=o.AddComponent<MeshRenderer>();float glow=materialName=="Headlight"?.65f:materialName=="Crystal"?.18f:materialName=="Taillight"?.4f:0;
    mr.sharedMaterial=Material(materialName,colors[kv.Key],glow);
   }
   foreach(var kv in wheelRoots){var bounds=new Bounds();bool first=true;foreach(var r in kv.Value.GetComponentsInChildren<Renderer>()){if(first){bounds=r.bounds;first=false;}else bounds.Encapsulate(r.bounds);}Vector3 center=root.transform.InverseTransformPoint(bounds.center);kv.Value.localPosition=center;foreach(Transform child in kv.Value)child.localPosition=-center;}
   return root;
  }
  public static void Customize(GameObject model,Color paint,Color accent,int wheels,int windows){
   foreach(var r in model.GetComponentsInChildren<MeshRenderer>()){
    if(r.name=="Paint")r.material.color=paint;
    if(r.name=="Accent")r.material.color=accent;
    if(r.name=="Wheel")r.material.color=new[]{new Color(.32f,.39f,.46f),new Color(.84f,.64f,.25f),new Color(.85f,.88f,.94f)}[wheels];
    if(r.name=="Glass")r.material.color=new[]{new Color(.045f,.12f,.17f),new Color(.1f,.38f,.48f),new Color(.3f,.18f,.4f)}[windows];
   }
  }
 }
 [Serializable] public class CarSpec {
  public string name,description;public float speed,accel,brake,grip,mass;
  public CarSpec(string n,string d,float s,float a,float b,float g,float m){name=n;description=d;speed=s;accel=a;brake=b;grip=g;mass=m;}
  public static CarSpec[] All={new CarSpec("Vanta","Wide-body supercar • balanced grip",72,13,23,9.3f,1220),new CarSpec("Comet","Muscle coupe • strong acceleration",68,15,21,8.4f,1410),new CarSpec("Miso","Compact hatch • agile cornering",62,14,25,10.5f,970),new CarSpec("Nomad","Rally buggy • forgiving over bumps",60,13.5f,24,9.7f,1160),new CarSpec("Spectre","Long-tail racer • highest top speed",79,11.7f,22,8.9f,1280)};
 }
}
