using System.Collections.Generic;
using UnityEngine;
namespace Aether {
 public class Vehicle:MonoBehaviour {
  public Rigidbody body;public CarSpec spec;public bool player,finished;public int place,carIndex,lastPoint;public float progress,finishTime,shield,boost,stun,energy=100;public string driver,item="";public float throttle,steer;public bool drift;
  public GameObject model;public float speed=>body?body.linearVelocity.magnitude*3.6f:0;public int grounded;public bool manualTest;float watchdog,watchProgress,overturned;
  Transform[] wheels=new Transform[4];Vector3[] hubs=new Vector3[4];float radius;float wheelSpin;float steerSmooth,stuck,fxTimer,aiItemTimer;TrailRenderer[] trails=new TrailRenderer[2];ParticleSystem smoke;AudioSource engine;float phase;
  public float engineTune,brakeTune,gripTune;TrackWorld track;Game game;Vector3 lastSafe;Quaternion safeRot;GameObject shieldVisual;TrailRenderer[] flames=new TrailRenderer[2];
  public void Initialize(Game g,int index,bool isPlayer,string name,Vector3 p,Quaternion q,int tune=0,int tires=0,int brakes=0){
   game=g;track=g.track;carIndex=index;spec=CarSpec.All[index];player=isPlayer;driver=name;transform.SetPositionAndRotation(p,q);gameObject.layer=8;
   engineTune=tune*1.5f;brakeTune=brakes*2;gripTune=tires*.8f;
   model=ModelLibrary.Create(spec.name,transform);var col=gameObject.AddComponent<BoxCollider>();col.center=new Vector3(0,.68f,0);col.size=new Vector3(index==3?1.8f:1.9f,.67f,index==2?3.55f:4.25f);
   body=gameObject.AddComponent<Rigidbody>();body.mass=spec.mass;body.centerOfMass=new Vector3(0,.3f,0);body.interpolation=RigidbodyInterpolation.Interpolate;body.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;body.linearDamping=.045f;body.angularDamping=2.1f;
   radius=index==3?.59f:index==2?.47f:index==1?.46f:index==4?.45f:.44f;
   string[] names={"WheelFL","WheelFR","WheelRL","WheelRR"};for(int i=0;i<4;i++){wheels[i]=model.transform.Find(names[i]);if(wheels[i])hubs[i]=wheels[i].localPosition;}
   for(int i=0;i<2;i++){var o=new GameObject("Tire marks");o.transform.SetParent(transform,false);trails[i]=o.AddComponent<TrailRenderer>();trails[i].time=18;trails[i].minVertexDistance=.22f;trails[i].widthMultiplier=.25f;trails[i].sharedMaterial=new Material(Shader.Find("Sprites/Default"));trails[i].startColor=new Color(.025f,.03f,.05f,.8f);trails[i].endColor=new Color(.025f,.03f,.05f,0);trails[i].emitting=false;}
   var sm=new GameObject("Tire smoke");sm.transform.SetParent(transform,false);sm.transform.localPosition=new Vector3(0,.22f,-1.6f);smoke=sm.AddComponent<ParticleSystem>();var main=smoke.main;main.startLifetime=.8f;main.startSpeed=1.7f;main.startSize=.6f;main.startColor=new Color(.72f,.76f,.85f,.4f);main.simulationSpace=ParticleSystemSimulationSpace.World;main.maxParticles=100;var emission=smoke.emission;emission.rateOverTime=0;var shape=smoke.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=new Vector3(1.9f,.2f,.2f);var size=smoke.sizeOverLifetime;size.enabled=true;size.size=new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,.3f,1,2.8f));smoke.GetComponent<ParticleSystemRenderer>().material=new Material(Shader.Find("Particles/Standard Unlit"));
   if(player){engine=gameObject.AddComponent<AudioSource>();engine.loop=true;engine.volume=.12f;engine.spatialBlend=0;engine.clip=MakeEngine();engine.Play();}
   smoke.GetComponent<ParticleSystemRenderer>().sharedMaterial=Game.FXMaterial();
   shieldVisual=GameObject.CreatePrimitive(PrimitiveType.Sphere);shieldVisual.name="Shield bubble";Destroy(shieldVisual.GetComponent<Collider>());shieldVisual.transform.SetParent(transform,false);shieldVisual.transform.localPosition=Vector3.up*.65f;shieldVisual.transform.localScale=new Vector3(3.1f,2.6f,5.8f);shieldVisual.GetComponent<Renderer>().sharedMaterial=new Material(Shader.Find("Aether/Shield"));shieldVisual.SetActive(false);
   for(int i=0;i<2;i++){var o=new GameObject("Boost exhaust");o.transform.SetParent(transform,false);o.transform.localPosition=new Vector3(i==0?-.51f:.51f,.42f,-2.4f);var t=o.AddComponent<TrailRenderer>();t.time=.09f;t.minVertexDistance=.08f;t.widthMultiplier=.26f;t.sharedMaterial=Game.FXMaterial();t.startColor=new Color(.25f,1,1,.9f);t.endColor=new Color(.3f,.7f,1,0);t.emitting=false;flames[i]=t;}
   lastPoint=track.Nearest(p);progress=lastPoint>TrackWorld.Count/2?lastPoint-TrackWorld.Count:lastPoint;lastSafe=p;safeRot=q;
  }
  AudioClip MakeEngine(){int count=44100;var clip=AudioClip.Create("Engine harmonics",count,1,44100,false);var samples=new float[count];for(int i=0;i<count;i++){float t=i/44100f;samples[i]=.22f*(Mathf.Sin(t*80*Mathf.PI*2)+.35f*Mathf.Sin(t*160*Mathf.PI*2)+.18f*Mathf.Sin(t*240*Mathf.PI*2));}clip.SetData(samples,0);return clip;}
  void Update(){
   if(game==null)return;if(game.state!=Game.State.Race){throttle=0;steer=0;drift=false;return;}
   if(!manualTest){if(player&&!finished){throttle=Input.GetAxisRaw("Vertical");steer=Input.GetAxisRaw("Horizontal");drift=Input.GetKey(KeyCode.Space);if(Input.GetKeyDown(KeyCode.E))UseItem();if(Input.GetKeyDown(KeyCode.R))Recover();if(Input.GetKey(KeyCode.LeftShift)&&energy>0&&throttle>0){boost=.12f;energy=Mathf.Max(0,energy-Time.deltaTime*27);}else energy=Mathf.Min(100,energy+Time.deltaTime*9);}else DriveAI();}
   shield=Mathf.Max(0,shield-Time.deltaTime);boost=Mathf.Max(0,boost-Time.deltaTime);stun=Mathf.Max(0,stun-Time.deltaTime);
   shieldVisual.SetActive(shield>0);foreach(var flame in flames)flame.emitting=boost>0;
   if(engine){engine.pitch=.65f+Mathf.Clamp(speed/180,0,1.7f)+Mathf.Abs(throttle)*.15f;engine.volume=game.volume*.25f;}
   if(body.linearVelocity.magnitude<2&&throttle>.5f)stuck+=Time.deltaTime;else stuck=0;if(!player&&stuck>3)Recover();if(transform.position.y<-25||Vector3.Dot(transform.up,Vector3.up)<.15f){stuck+=Time.deltaTime;if(stuck>2.5f)Recover();}
   int point=track.Nearest(transform.position);int delta=point-lastPoint;if(delta>TrackWorld.Count/2)delta-=TrackWorld.Count;if(delta<-TrackWorld.Count/2)delta+=TrackWorld.Count;
   if(Mathf.Abs(delta)<20&&TrackWorld.FlatDistance(transform.position,track.points[point])<22)progress+=delta;lastPoint=point;
   if(!player&&!finished&&!manualTest){if(progress>watchProgress+3){watchProgress=progress;watchdog=0;}else watchdog+=Time.deltaTime;if(watchdog>5){Recover();watchdog=0;watchProgress=progress;}}
   if(Vector3.Dot(transform.up,Vector3.up)<.3f||transform.position.y<-20)overturned+=Time.deltaTime;else overturned=0;if(overturned>2.5f){Recover();overturned=0;}
   if(!finished&&progress>=game.laps*TrackWorld.Count){finished=true;finishTime=game.raceTime;game.OnFinish(this);}
  }
  void DriveAI(){
   int near=track.Nearest(transform.position);int ahead=Mathf.RoundToInt(5+speed/28);Vector3 target=track.points[(near+ahead)%TrackWorld.Count]+track.Right(near)*Mathf.Sin(carIndex*1.7f+place)*3;
   foreach(var v in game.racers){if(v==this)continue;Vector3 local=transform.InverseTransformPoint(v.transform.position);if(local.z>0&&local.z<13&&Mathf.Abs(local.x)<2.7f)target+=track.Right(near)*(local.x>0?-3:3);}
   Vector3 localTarget=transform.InverseTransformPoint(target);float angle=Mathf.Atan2(localTarget.x,localTarget.z)*Mathf.Rad2Deg;steer=Mathf.Clamp(angle/25,-1,1);
   float bend=Vector3.Angle(track.Forward(near),track.Forward((near+ahead*2)%TrackWorld.Count));float desired=Mathf.Lerp(175,70,Mathf.Clamp01(bend/65))*game.difficultyFactor;throttle=speed>desired?-Mathf.Clamp((speed-desired)/30,0,.65f):1;drift=false;
   aiItemTimer+=Time.deltaTime;if(aiItemTimer>4&&item!=""){UseItem();aiItemTimer=0;}
  }
  void FixedUpdate(){
   if(game==null||body==null)return;
   bool active=game.state==Game.State.Race;float accel=active?throttle:0;steerSmooth=Mathf.MoveTowards(steerSmooth,steer,Time.fixedDeltaTime*3);float forwardSpeed=Vector3.Dot(body.linearVelocity,transform.forward);
   grounded=0;wheelSpin+=forwardSpeed/radius*Mathf.Rad2Deg*Time.fixedDeltaTime;float slip=Mathf.Abs(Vector3.Dot(body.linearVelocity,transform.right));
   for(int i=0;i<4;i++){
    Vector3 origin=transform.TransformPoint(hubs[i]+Vector3.up*.32f);bool contact=Physics.Raycast(origin,-transform.up,out RaycastHit hit,radius+.65f,~((1<<8)|(1<<9)),QueryTriggerInteraction.Ignore);
    Quaternion turn=Quaternion.Euler(0,i<2?steerSmooth*Mathf.Lerp(30,12,Mathf.Clamp01(speed/230)):0,0);Vector3 fwd=transform.rotation*turn*Vector3.forward;Vector3 right=transform.rotation*turn*Vector3.right;
    if(contact){grounded++;float compression=.32f-(hit.distance-radius);Vector3 velocity=body.GetPointVelocity(origin);float spring=Mathf.Clamp(compression*(carIndex==3?30000:36000)-Vector3.Dot(velocity,transform.up)*4200,0,26000);body.AddForceAtPosition(hit.normal*spring,origin);
     float lateral=Vector3.Dot(velocity,right);float grip=(spec.grip+gripTune)*(drift&&i>=2?.36f:1);body.AddForceAtPosition(-right*Mathf.Clamp(lateral*grip,-14,14)*body.mass/4,hit.point);
     float a=(spec.accel+engineTune)*(boost>0?1.8f:1)*(stun>0?.15f:1);float cap=spec.speed+engineTune*2+(boost>0?22:0);
     if(accel>0&&forwardSpeed<cap)body.AddForceAtPosition(fwd*accel*a*body.mass/4,hit.point);
     if(accel<0){if(forwardSpeed>1.2f)body.AddForceAtPosition(-fwd*(-accel)*(spec.brake+brakeTune)*body.mass/4,hit.point);else if(forwardSpeed>-13)body.AddForceAtPosition(fwd*accel*a*.55f*body.mass/4,hit.point);}
     if(!active)body.AddForceAtPosition(-fwd*Vector3.Dot(velocity,fwd)*body.mass*2,hit.point);
     if(wheels[i])wheels[i].localPosition=hubs[i]+Vector3.up*Mathf.Clamp(compression,-.3f,.3f);
     if(i>=2){trails[i-2].transform.position=hit.point+hit.normal*.028f;trails[i-2].emitting=active&&speed>28&&(drift||slip>4);}
    }else{if(wheels[i])wheels[i].localPosition=hubs[i]-Vector3.up*.15f;if(i>=2)trails[i-2].emitting=false;}
    if(wheels[i])wheels[i].localRotation=turn*Quaternion.Euler(wheelSpin,0,0);
   }
   if(grounded>1){body.AddForce(-transform.up*body.linearVelocity.sqrMagnitude*1.6f);float targetYaw=steerSmooth*Mathf.Clamp(forwardSpeed/18,-.7f,1.5f)*(drift?1.35f:1);body.AddTorque(Vector3.up*(targetYaw-body.angularVelocity.y)*body.mass*1.7f);body.AddTorque(Vector3.Cross(transform.up,Vector3.up)*body.mass*3);}
   var emission=smoke.emission;emission.rateOverTime=active&&grounded>1&&speed>25&&(drift||slip>4)?34:0;
   if(drift&&speed>55&&grounded>1&&player)energy=Mathf.Min(100,energy+Time.fixedDeltaTime*16);
  }
  public void Recover(){int n=lastPoint;body.position=track.points[n]+Vector3.up*.6f;body.rotation=Quaternion.LookRotation(track.Forward(n));body.linearVelocity=Vector3.zero;body.angularVelocity=Vector3.zero;Physics.SyncTransforms();stuck=0;overturned=0;foreach(var t in trails)t.Clear();if(player)game.Toast("Car reset to the road");}
  public void UseItem(){if(item=="")return;string used=item;item="";if(used=="Boost"){boost=3.2f;}else if(used=="Shield"){shield=8;}else if(used=="Pulse"){game.Burst(transform.position,new Color(.4f,1,1),3);foreach(var v in game.racers)if(v!=this&&Vector3.Distance(v.transform.position,transform.position)<22)v.Hit((v.transform.position-transform.position).normalized*8);}else if(used=="Rocket"){var o=GameObject.CreatePrimitive(PrimitiveType.Sphere);o.name="Rocket";o.transform.position=transform.position+transform.forward*3+Vector3.up*.7f;o.transform.localScale=Vector3.one*.5f;Destroy(o.GetComponent<Collider>());o.GetComponent<Renderer>().sharedMaterial=ModelLibrary.Material("rocket",new Color(1,.32f,.2f),.7f);var r=o.AddComponent<Rocket>();r.owner=this;r.game=game;r.direction=transform.forward;}
   if(player)game.Toast(used+" activated");}
  public void Hit(Vector3 impulse){if(shield>0){shield=0;game.Burst(transform.position,Color.cyan,1);return;}body.AddForce(impulse+Vector3.up*2,ForceMode.VelocityChange);stun=1.2f;if(player)game.cameraShake=.6f;}
  void OnCollisionEnter(Collision c){if(game==null||c.relativeVelocity.magnitude<3||Time.time-fxTimer<.15f)return;fxTimer=Time.time;game.Burst(c.GetContact(0).point,new Color(1,.65f,.25f),Mathf.Clamp(c.relativeVelocity.magnitude/10,.4f,1.6f));if(player)game.cameraShake=Mathf.Min(.6f,c.relativeVelocity.magnitude*.018f);}
 }
 public class Rocket:MonoBehaviour {public Vehicle owner;public Game game;public Vector3 direction;float age;void Update(){age+=Time.deltaTime;Vehicle target=null;float d=120;foreach(var v in game.racers){float dist=Vector3.Distance(v.transform.position,transform.position);if(v!=owner&&Vector3.Dot(direction,v.transform.position-transform.position)>0&&dist<d){target=v;d=dist;}}if(target)direction=Vector3.RotateTowards(direction,(target.transform.position+Vector3.up*.7f-transform.position).normalized,Time.deltaTime*2,0);transform.position+=direction*95*Time.deltaTime;foreach(var v in game.racers)if(v!=owner&&Vector3.Distance(v.transform.position+Vector3.up*.6f,transform.position)<2.6f){v.Hit(direction*10);game.Burst(transform.position,new Color(1,.35f,.13f),2);Destroy(gameObject);return;}if(age>5)Destroy(gameObject);}}
}
