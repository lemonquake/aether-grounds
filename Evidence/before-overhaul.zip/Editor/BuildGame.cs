using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using System.IO;
public static class BuildGame {
 [MenuItem("Aether Grounds/Open Game Scene")]
 public static void OpenScene(){EditorSceneManager.OpenScene("Assets/Scenes/AetherGrounds.unity");if(SceneView.lastActiveSceneView)SceneView.lastActiveSceneView.LookAt(new Vector3(0,.65f,0),Quaternion.Euler(18,-35,0),7);}
 [MenuItem("Aether Grounds/Export Editable Prefabs")]
 public static void BakeModels(){
  Directory.CreateDirectory("Assets/Art/Prefabs");Directory.CreateDirectory("Assets/Art/Meshes");Directory.CreateDirectory("Assets/Art/Materials");AssetDatabase.Refresh();
  foreach(string name in new[]{"Vanta","Comet","Miso","Nomad","Spectre","AlienTree","CrystalCluster","Rock","RaceArch","RoadModule","TrackStation"}){
   var root=Aether.ModelLibrary.Create(name);int i=0;
   foreach(var mf in root.GetComponentsInChildren<MeshFilter>()){
    var mesh=mf.sharedMesh;string path="Assets/Art/Meshes/"+name+"_"+i+++".asset";var existing=AssetDatabase.LoadAssetAtPath<Mesh>(path);
    if(existing){EditorUtility.CopySerialized(mesh,existing);mf.sharedMesh=existing;}else if(!AssetDatabase.Contains(mesh))AssetDatabase.CreateAsset(mesh,path);
    var renderer=mf.GetComponent<MeshRenderer>();var material=renderer.sharedMaterial;string mp="Assets/Art/Materials/"+material.name+".mat";var em=AssetDatabase.LoadAssetAtPath<Material>(mp);if(em)renderer.sharedMaterial=em;else if(!AssetDatabase.Contains(material))AssetDatabase.CreateAsset(material,mp);
   }
   PrefabUtility.SaveAsPrefabAsset(root,"Assets/Art/Prefabs/"+name+".prefab");Object.DestroyImmediate(root);
  }
  AssetDatabase.SaveAssets();
 }
 public static void Build(){
  BakeModels();
  EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var root=new GameObject("Aether Grounds");root.AddComponent<Aether.Game>();
  var preview=new GameObject("Editor Preview");preview.tag="EditorOnly";var model=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Art/Prefabs/Vanta.prefab"));model.transform.SetParent(preview.transform);
  EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),"Assets/Scenes/AetherGrounds.unity");
  PlayerSettings.companyName="Aljay Leodones";PlayerSettings.productName="Aether Grounds";PlayerSettings.defaultScreenWidth=1600;PlayerSettings.defaultScreenHeight=900;PlayerSettings.fullScreenMode=FullScreenMode.Windowed;PlayerSettings.resizableWindow=true;PlayerSettings.runInBackground=true;PlayerSettings.colorSpace=ColorSpace.Gamma;PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone,ScriptingImplementation.Mono2x);
  var shaders=new[]{Shader.Find("Aether/Toon"),Shader.Find("Aether/Sky"),Shader.Find("Aether/Shield"),Shader.Find("Sprites/Default"),Shader.Find("Particles/Standard Unlit")};
  var settings=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);var property=settings.FindProperty("m_AlwaysIncludedShaders");int start=property.arraySize;property.arraySize+=shaders.Length;for(int i=0;i<shaders.Length;i++)property.GetArrayElementAtIndex(start+i).objectReferenceValue=shaders[i];settings.ApplyModifiedProperties();
  EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/AetherGrounds.unity",true)};AssetDatabase.SaveAssets();
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/AetherGrounds.unity"},locationPathName="Build/Aether Grounds.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.Development});
  File.WriteAllText("Evidence/build-result.txt",report.summary.result+" | errors="+report.summary.totalErrors+" | bytes="+report.summary.totalSize);
  if(report.summary.result!=BuildResult.Succeeded)throw new System.Exception("Build failed");
 }
}
