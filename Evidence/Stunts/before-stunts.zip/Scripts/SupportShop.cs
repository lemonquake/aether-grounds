using System;
using System.Text;
using System.Security.Cryptography;
using UnityEngine;
namespace Aether {
 public sealed class SupportProduct {
  public string id,name,description,price;public int body;public Color color;
  public SupportProduct(string i,string n,string d,string p,int b,Color c){id=i;name=n;description=d;price=p;body=b;color=c;}
 }
 public static class SupportStore {
  public const string Recipient="lemonquake@gmail.com";
  public static readonly SupportProduct[] Products={
   new SupportProduct("pip-city","Pip City Edition","Bubble compact with fender trim and a roof rack.","0.99",6,new Color(.9f,.59f,.22f)),
   new SupportProduct("comet-chrome","Comet Chrome Edition","Muscle coupe with chrome scoops and side pipes.","2.99",1,new Color(.75f,.83f,.9f)),
   new SupportProduct("nomad-night","Nomad Night Edition","Rally buggy with a roof light bar and brush guard.","5.99",3,new Color(.23f,.7f,.58f)),
   new SupportProduct("manta-gold","Manta Gold Edition","Prototype with gold aero fins and splitter.","9.99",9,new Color(.95f,.67f,.24f)),
   new SupportProduct("neon-wheels","Neon wheel kit","Cyan illuminated hub rings for your saved cars.","0.99",-1,Color.cyan),
   new SupportProduct("star-trail","Starlight trail","A violet particle trail while using boost.","1.99",-1,new Color(.7f,.4f,1))};
  public static SupportProduct Product(string id)=>Array.Find(Products,p=>p.id==id);
  public static string PlayerId {get {var id=PlayerPrefs.GetString("support-player-id","");if(id.Length!=16){id=Guid.NewGuid().ToString("N").Substring(0,16);PlayerPrefs.SetString("support-player-id",id);PlayerPrefs.Save();}return id;}}
  public static string Checkout(SupportProduct p,string id)=>"https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business="+Uri.EscapeDataString(Recipient)+"&item_name="+Uri.EscapeDataString("Aether Grounds - "+p.name)+"&item_number="+p.id+"&amount="+p.price+"&currency_code=USD&no_shipping=1&custom="+Uri.EscapeDataString(id)+"&charset=utf-8";
  public static bool Verify(string token,string player,out string sku){sku="";try{var pieces=token.Trim().Split('.');if(pieces.Length!=2)return false;var data=Convert.FromBase64String(pieces[0]);var fields=Encoding.UTF8.GetString(data).Split('|');if(fields.Length!=4||fields[0]!="AG1"||fields[1]!=player||Product(fields[2])==null||fields[3].Length<4)return false;
    var key=Resources.Load<TextAsset>("Commerce/SupportPublicKey");if(!key)return false;using(var rsa=new RSACryptoServiceProvider()){rsa.FromXmlString(key.text);if(!rsa.VerifyData(data,CryptoConfig.MapNameToOID("SHA256"),Convert.FromBase64String(pieces[1])))return false;}sku=fields[2];return true;
   }catch{return false;}}
  static readonly System.Collections.Generic.Dictionary<string,bool> owned=new System.Collections.Generic.Dictionary<string,bool>();
  public static bool Owned(string sku){if(owned.TryGetValue(sku,out bool result))return result;return owned[sku]=CheckOwned(sku);}
  static bool CheckOwned(string sku){var token=PlayerPrefs.GetString("support-license-"+sku,"");return token.Length>0&&Verify(token,PlayerId,out var verified)&&verified==sku;}
  public static bool Redeem(string code){if(!Verify(code,PlayerId,out var sku))return false;PlayerPrefs.SetString("support-license-"+sku,code.Trim());PlayerPrefs.Save();owned.Remove(sku);return true;}
  public static void Apply(GameObject model,SavedCar car){
   if(!string.IsNullOrEmpty(car.supportEdition)&&Owned(car.supportEdition)){
    var product=Product(car.supportEdition);if(product!=null&&product.body==car.body){var trim=ModelLibrary.Material("Support edition "+product.id,product.color,.08f);var kit=new GameObject(product.name+" body kit");kit.transform.SetParent(model.transform,false);
     if(product.id=="pip-city"||product.id=="nomad-night"){for(int s=-1;s<=1;s+=2)CarParts.Part(kit.transform,"Roof rail",PrimitiveType.Cube,new Vector3(s*.62f,car.body==3?1.7f:1.5f,-.2f),new Vector3(.08f,.09f,1.6f),trim);for(int i=-2;i<=2;i++)CarParts.Part(kit.transform,"Roof bar",PrimitiveType.Cube,new Vector3(0,car.body==3?1.72f:1.52f,i*.35f),new Vector3(1.4f,.07f,.07f),trim);}
     if(product.id=="nomad-night")for(int i=-2;i<=2;i++)CarParts.Part(kit.transform,"Rally lamp",PrimitiveType.Sphere,new Vector3(i*.25f,1.84f,.65f),Vector3.one*.21f,ModelLibrary.Material("Rally lamp",Color.white,1.4f));
     for(int s=-1;s<=1;s+=2){CarParts.Part(kit.transform,"Side sill",PrimitiveType.Cube,new Vector3(s*.98f,.36f,0),new Vector3(.17f,.15f,2.5f),trim);if(product.id=="comet-chrome")CarParts.Part(kit.transform,"Chrome side pipe",PrimitiveType.Cylinder,new Vector3(s*1.02f,.45f,-.15f),new Vector3(.18f,1.1f,.18f),trim,new Vector3(90,0,0));if(product.id=="manta-gold")CarParts.Part(kit.transform,"Aero fin",PrimitiveType.Cube,new Vector3(s*.96f,.8f,-1.8f),new Vector3(.08f,.8f,.75f),trim,new Vector3(0,0,s*8));}
     CarParts.Part(kit.transform,"Front splitter",PrimitiveType.Cube,new Vector3(0,.29f,1.9f),new Vector3(2.12f,.08f,.38f),trim);
    }
   }
   if(car.neonWheels&&Owned("neon-wheels"))foreach(string name in new[]{"WheelFL","WheelFR","WheelRL","WheelRR"}){var hub=model.transform.Find(name);if(hub)CarParts.Part(hub,"Neon hub",PrimitiveType.Cylinder,new Vector3(name.EndsWith("L")?-.16f:.16f,0,0),new Vector3(.57f,.024f,.57f),ModelLibrary.Material("Neon hubs",Color.cyan,1.8f),new Vector3(0,0,90));}
  }
 }
 public partial class Game {
  int supportChoice;string unlockCode="";
  void SupportGUI(){
   Panel(25,116,1550,655,.98f);Label("Support the game",50,133,650,52,38,null,true);Label("Optional cars and cosmetic items · USD · one-time purchases",52,191,1100,35,22,muted);
   for(int i=0;i<SupportStore.Products.Length;i++){var p=SupportStore.Products[i];float x=50+(i%3)*350,y=252+(i/3)*222;Card(x,y,333,205,supportChoice==i?new Color(.075f,.19f,.22f):new Color(.055f,.085f,.12f));Label(p.name,x+16,y+12,305,40,23,Color.Lerp(p.color,Color.white,.42f),true);Label(p.description,x+16,y+59,300,70,19,muted);if(Button((SupportStore.Owned(p.id)?"Owned · ":"$")+(!SupportStore.Owned(p.id)?p.price+" · ":"")+"View",x+16,y+146,300,43,supportChoice==i))supportChoice=i;}
   var selected=SupportStore.Products[supportChoice];Card(1132,249,415,449);Label(selected.name,1151,270,376,60,28,Color.Lerp(selected.color,Color.white,.42f),true);Label("$"+selected.price+" USD",1151,334,376,42,31,null,true);Label("PayPal recipient\nAljay Leodones\nlemonquake@gmail.com",1151,392,376,91,22,muted);
   Label("After payment, email your receipt and Player ID to receive an unlock code. Delivery is manual.",1151,498,376,115,20,muted);
   if(SupportStore.Owned(selected.id)){if(Button("Use on saved car",1151,628,376,49,true)){if(selected.body>=0){CurrentCar.body=selected.body;CurrentCar.supportEdition=selected.id;}else if(selected.id=="neon-wheels")CurrentCar.neonWheels=!CurrentCar.neonWheels;else CurrentCar.starTrail=!CurrentCar.starTrail;Changed();Toast("Saved car updated");}}
   else if(Button("Buy with PayPal",1151,628,376,49,true))Application.OpenURL(SupportStore.Checkout(selected,SupportStore.PlayerId));
   Label("Player ID: "+SupportStore.PlayerId,52,712,565,37,22,cyan);if(Button("Copy Player ID",663,709,240,41))GUIUtility.systemCopyBuffer=SupportStore.PlayerId;
   Panel(25,786,1550,98,.98f);Label("Unlock code",48,804,190,36,23);unlockCode=GUI.TextField(new Rect(237,800,824,53),unlockCode,1500,new GUIStyle(GUI.skin.textField){fontSize=20,padding=new RectOffset(12,12,12,12)});if(Button("Paste",1076,800,160,53))unlockCode=GUIUtility.systemCopyBuffer;if(Button("Unlock",1251,800,294,53,true))Toast(SupportStore.Redeem(unlockCode)?"Item unlocked · select it and use on your car":"Code not valid for this Player ID");
  }
 }
}
